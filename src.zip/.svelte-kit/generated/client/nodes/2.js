import * as universal from "../../../../src/routes/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/+page.svelte";
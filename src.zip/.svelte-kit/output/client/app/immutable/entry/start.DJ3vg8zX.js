import{e as a}from"../chunks/B0WJ0K4d.js";export{a as start};

import{Y as o}from"./Cau2KnCl.js";const s=o;export{s as d};

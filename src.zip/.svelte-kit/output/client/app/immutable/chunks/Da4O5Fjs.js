import{Z as a}from"./Cau2KnCl.js";a();



export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["app/immutable/nodes/1.BITJiy2T.js","app/immutable/chunks/DQvA0ISM.js","app/immutable/chunks/Cau2KnCl.js","app/immutable/chunks/Da4O5Fjs.js","app/immutable/chunks/Bwrweyp0.js","app/immutable/chunks/BcRrr1px.js","app/immutable/chunks/B0WJ0K4d.js","app/immutable/chunks/Bg0QjkY6.js"];
export const stylesheets = [];
export const fonts = [];

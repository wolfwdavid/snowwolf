import * as universal from '../entries/pages/home/_page.js';

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/home/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/home/+page.js";
export const imports = ["app/immutable/nodes/4.2ygvFiu6.js","app/immutable/chunks/VlUHd9Rj.js","app/immutable/chunks/Cau2KnCl.js","app/immutable/chunks/DQvA0ISM.js","app/immutable/chunks/Da4O5Fjs.js","app/immutable/chunks/Bwrweyp0.js","app/immutable/chunks/e8Dr9VYj.js","app/immutable/chunks/BUDk7LXN.js","app/immutable/chunks/DdRLWcaq.js","app/immutable/chunks/DDIuyo6r.js"];
export const stylesheets = ["app/immutable/assets/4.DkmHJ1NX.css"];
export const fonts = [];

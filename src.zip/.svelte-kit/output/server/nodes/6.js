import * as universal from '../entries/pages/sverdle/how-to-play/_page.js';

export const index = 6;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/sverdle/how-to-play/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/sverdle/how-to-play/+page.js";
export const imports = ["app/immutable/nodes/6.DdZdshIh.js","app/immutable/chunks/VlUHd9Rj.js","app/immutable/chunks/Cau2KnCl.js","app/immutable/chunks/DQvA0ISM.js","app/immutable/chunks/Da4O5Fjs.js"];
export const stylesheets = ["app/immutable/assets/6.Dv9QCmvw.css"];
export const fonts = [];

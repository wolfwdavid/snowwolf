import * as universal from '../entries/pages/_page.js';

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/+page.js";
export const imports = ["app/immutable/nodes/2.bnpGiRgy.js","app/immutable/chunks/DQvA0ISM.js","app/immutable/chunks/Cau2KnCl.js","app/immutable/chunks/Da4O5Fjs.js","app/immutable/chunks/Bwrweyp0.js","app/immutable/chunks/e8Dr9VYj.js","app/immutable/chunks/BUDk7LXN.js","app/immutable/chunks/DdRLWcaq.js","app/immutable/chunks/DDIuyo6r.js"];
export const stylesheets = ["app/immutable/assets/2.mV3zmUXl.css"];
export const fonts = [];

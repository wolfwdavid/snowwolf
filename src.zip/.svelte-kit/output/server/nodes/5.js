import * as server from '../entries/pages/sverdle/_page.server.js';

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/sverdle/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/sverdle/+page.server.js";
export const imports = ["app/immutable/nodes/5.DYXtuAgg.js","app/immutable/chunks/DQvA0ISM.js","app/immutable/chunks/Cau2KnCl.js","app/immutable/chunks/Bwrweyp0.js","app/immutable/chunks/e8Dr9VYj.js","app/immutable/chunks/BUDk7LXN.js","app/immutable/chunks/DdRLWcaq.js","app/immutable/chunks/zEmtvFNt.js","app/immutable/chunks/B0WJ0K4d.js","app/immutable/chunks/Bg0QjkY6.js"];
export const stylesheets = ["app/immutable/assets/5.yeGN9jlM.css"];
export const fonts = [];

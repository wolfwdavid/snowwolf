export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "app",
	appPath: "snowwolf/app",
	assets: new Set([".nojekyll","favicon.png","robots.txt","_redirects"]),
	mimeTypes: {".png":"image/png",".txt":"text/plain"},
	_: {
		client: {start:"app/immutable/entry/start.DJ3vg8zX.js",app:"app/immutable/entry/app.DRfwfhYC.js",imports:["app/immutable/entry/start.DJ3vg8zX.js","app/immutable/chunks/B0WJ0K4d.js","app/immutable/chunks/Cau2KnCl.js","app/immutable/chunks/Bg0QjkY6.js","app/immutable/entry/app.DRfwfhYC.js","app/immutable/chunks/Bg0QjkY6.js","app/immutable/chunks/Cau2KnCl.js","app/immutable/chunks/Bwrweyp0.js","app/immutable/chunks/DQvA0ISM.js","app/immutable/chunks/e8Dr9VYj.js","app/immutable/chunks/zEmtvFNt.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/3.js')),
			__memo(() => import('./nodes/4.js')),
			__memo(() => import('./nodes/5.js')),
			__memo(() => import('./nodes/6.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			},
			{
				id: "/create_an_account",
				pattern: /^\/create_an_account\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			},
			{
				id: "/home",
				pattern: /^\/home\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/sverdle",
				pattern: /^\/sverdle\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/sverdle/how-to-play",
				pattern: /^\/sverdle\/how-to-play\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 6 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

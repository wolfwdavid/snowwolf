export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "app",
	appPath: "snowwolf/app",
	assets: new Set([".nojekyll","favicon.png","robots.txt","_redirects"]),
	mimeTypes: {".png":"image/png",".txt":"text/plain"},
	_: {
		client: {start:"app/immutable/entry/start.DJ3vg8zX.js",app:"app/immutable/entry/app.DRfwfhYC.js",imports:["app/immutable/entry/start.DJ3vg8zX.js","app/immutable/chunks/B0WJ0K4d.js","app/immutable/chunks/Cau2KnCl.js","app/immutable/chunks/Bg0QjkY6.js","app/immutable/entry/app.DRfwfhYC.js","app/immutable/chunks/Bg0QjkY6.js","app/immutable/chunks/Cau2KnCl.js","app/immutable/chunks/Bwrweyp0.js","app/immutable/chunks/DQvA0ISM.js","app/immutable/chunks/e8Dr9VYj.js","app/immutable/chunks/zEmtvFNt.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/5.js'))
		],
		routes: [
			{
				id: "/sverdle",
				pattern: /^\/sverdle\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			}
		],
		prerendered_routes: new Set(["/snowwolf/","/snowwolf/home","/snowwolf/sverdle/how-to-play"]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

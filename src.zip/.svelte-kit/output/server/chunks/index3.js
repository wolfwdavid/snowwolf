import { D as DEV } from "./false.js";
const dev = DEV;
export {
  dev as d
};

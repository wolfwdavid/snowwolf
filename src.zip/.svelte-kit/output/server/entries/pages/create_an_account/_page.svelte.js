import { h as head, s as stringify } from "../../../chunks/index.js";
import { a as attr } from "../../../chunks/attributes.js";
import { e as escape_html } from "../../../chunks/escaping.js";
function _page($$payload) {
  let fullName = "";
  let email = "";
  let password = "";
  let confirmPassword = "";
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>Create an Account</title>`;
    $$payload2.out += `<meta name="description" content="Sign up for Snowwolf and explore new tools!" class="svelte-1fbb6hw">`;
  });
  $$payload.out += `<a${attr("href", `${stringify(base)}/dashboard`)} class="svelte-1fbb6hw">Go to Dashboard</a>  <div class="signup-container svelte-1fbb6hw"><div class="form-container svelte-1fbb6hw"><h2 class="svelte-1fbb6hw">Create a New Account</h2> <p class="svelte-1fbb6hw">Join Snowwolf Today</p> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> <form class="svelte-1fbb6hw"><div class="input-group svelte-1fbb6hw"><label class="svelte-1fbb6hw">Full Name</label> <input type="text" placeholder="Enter your full name"${attr("value", fullName)} required class="svelte-1fbb6hw"></div> <div class="input-group svelte-1fbb6hw"><label class="svelte-1fbb6hw">Email Address</label> <input type="email" placeholder="Enter your email"${attr("value", email)} required class="svelte-1fbb6hw"></div> <div class="input-group password-group svelte-1fbb6hw"><label class="svelte-1fbb6hw">Password</label> <input${attr("type", "password")} placeholder="Enter password"${attr("value", password)} required class="svelte-1fbb6hw"> <span class="toggle-icon svelte-1fbb6hw">${escape_html("👁️")}</span></div> <div class="input-group password-group svelte-1fbb6hw"><label class="svelte-1fbb6hw">Confirm Password</label> <input${attr("type", "password")} placeholder="Confirm password"${attr("value", confirmPassword)} required class="svelte-1fbb6hw"> <span class="toggle-icon svelte-1fbb6hw">${escape_html("👁️")}</span></div> <button type="submit" class="signup-btn svelte-1fbb6hw">Sign Up</button> <p class="login-text svelte-1fbb6hw">Already have an account? <a href="/login" class="svelte-1fbb6hw">Log in</a></p></form></div> <div class="image-container svelte-1fbb6hw"><img src="/images/signup-illustration.png" alt="Signup Illustration" class="svelte-1fbb6hw"></div></div>`;
}
export {
  _page as default
};

import { e as ensure_array_like, h as head, s as stringify } from "../../../chunks/index.js";
import { a as attr } from "../../../chunks/attributes.js";
import { e as escape_html } from "../../../chunks/escaping.js";
const wolf = "/snowwolf/app/immutable/assets/snowwolf.DFHP9UuQ.png";
function _page($$payload) {
  let searchQuery = "";
  const categories = ["Marketing", "AI Tools", "Business"];
  const each_array = ensure_array_like(categories);
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>Home - Snowwolf</title>`;
    $$payload2.out += `<meta name="description" content="Discover trending business tools and emerging AI startups." class="svelte-1qzndkm">`;
  });
  $$payload.out += `<section class="home-page svelte-1qzndkm"><header class="nav svelte-1qzndkm"><div class="logo svelte-1qzndkm"><img alt="wolf"${attr("src", wolf)} width="60" height="60" class="svelte-1qzndkm"> <span class="logo-text svelte-1qzndkm">SNOWWOLF</span></div></header> <h2 class="tagline svelte-1qzndkm">Find emerging startups &amp; latest tools</h2> <div class="search-container svelte-1qzndkm"><div class="search-bar svelte-1qzndkm"><input type="text" placeholder="What is your business and what are you looking for?"${attr("value", searchQuery)} aria-label="Search" class="svelte-1qzndkm"> <svg class="search-icon svelte-1qzndkm" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path d="M10 2a8 8 0 1 0 0 16 8 8 0 0 0 0-16zm0 14a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm9.7 5.3l-5.1-5.1a7.9 7.9 0 0 0 1.1-4.2 8 8 0 1 0-8 8 7.9 7.9 0 0 0 4.2-1.1l5.1 5.1a1 1 0 1 0 1.4-1.4z" class="svelte-1qzndkm"></path></svg></div></div> <div class="categories svelte-1qzndkm"><!--[-->`;
  for (let $$index_2 = 0, $$length = each_array.length; $$index_2 < $$length; $$index_2++) {
    let category = each_array[$$index_2];
    $$payload.out += `<div class="category-container svelte-1qzndkm"><button class="category-button svelte-1qzndkm">${escape_html(category)}</button> <div class="subtext svelte-1qzndkm"><span class="svelte-1qzndkm">Trending</span> <span class="separator svelte-1qzndkm">|</span> <span class="svelte-1qzndkm">Emerging</span></div> `;
    if (category === "Marketing") {
      $$payload.out += "<!--[-->";
      const each_array_1 = ensure_array_like(Array(6));
      $$payload.out += `<div class="marketing-grid svelte-1qzndkm"><!--[-->`;
      for (let row = 0, $$length2 = each_array_1.length; row < $$length2; row++) {
        each_array_1[row];
        const each_array_2 = ensure_array_like(Array(2));
        $$payload.out += `<div class="company-row svelte-1qzndkm"><!--[-->`;
        for (let col = 0, $$length3 = each_array_2.length; col < $$length3; col++) {
          each_array_2[col];
          $$payload.out += `<div class="company-item svelte-1qzndkm"><div class="icon svelte-1qzndkm">📊</div> <div class="bar svelte-1qzndkm"><div class="progress svelte-1qzndkm"${attr("style", `width: ${stringify(row === 0 && col === 0 ? "80%" : "67%")};`)}></div></div> <div class="percent svelte-1qzndkm">${escape_html(row === 0 && col === 0 ? "80%" : "67%")}</div></div>`;
        }
        $$payload.out += `<!--]--></div>`;
      }
      $$payload.out += `<!--]--></div>`;
    } else {
      $$payload.out += "<!--[!-->";
    }
    $$payload.out += `<!--]--></div>`;
  }
  $$payload.out += `<!--]--></div></section> <footer class="footer svelte-1qzndkm"><p class="svelte-1qzndkm">Trending Tools &amp; Profiles</p> <h1 class="svelte-1qzndkm">HOME PAGE</h1></footer>`;
}
export {
  _page as default
};

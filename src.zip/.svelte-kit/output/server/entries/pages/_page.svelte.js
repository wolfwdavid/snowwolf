import { e as ensure_array_like, h as head } from "../../chunks/index.js";
import { a as attr } from "../../chunks/attributes.js";
import { e as escape_html } from "../../chunks/escaping.js";
const wolf = "/snowwolf/app/immutable/assets/wolf.IeErWsEQ.png";
function _page($$payload) {
  let searchQuery = "";
  const categories = ["Marketing", "AI Tools", "Business"];
  const each_array = ensure_array_like(categories);
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>Welcome to Snow Wolf</title>`;
    $$payload2.out += `<meta name="description" content="Discover new business tools &amp; emerging startups.">`;
  });
  $$payload.out += `<section class="landing-page svelte-dggjqe"><div class="logo-container svelte-dggjqe"><img alt="wolf"${attr("src", wolf)} width="50" height="50"> <span class="logo-text svelte-dggjqe">SNOW WOLF</span> <span class="tagline svelte-dggjqe">Search engine supporting the underdogs</span></div> <hr class="styled-line svelte-dggjqe"> <div class="search-container svelte-dggjqe"><div class="search-bar svelte-dggjqe"><input type="text" placeholder="What is your business and what are you looking for?"${attr("value", searchQuery)} aria-label="Search" class="svelte-dggjqe"> <svg class="search-icon svelte-dggjqe" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path d="M10 2a8 8 0 1 0 0 16 8 8 0 0 0 0-16zm0 14a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm9.7 5.3l-5.1-5.1a7.9 7.9 0 0 0 1.1-4.2 8 8 0 1 0-8 8 7.9 7.9 0 0 0 4.2-1.1l5.1 5.1a1 1 0 1 0 1.4-1.4z"></path></svg></div></div> <div class="categories svelte-dggjqe"><!--[-->`;
  for (let $$index_2 = 0, $$length = each_array.length; $$index_2 < $$length; $$index_2++) {
    let category = each_array[$$index_2];
    $$payload.out += `<div class="category-container svelte-dggjqe"><button class="category-button svelte-dggjqe">${escape_html(category)}</button> <div class="subtext svelte-dggjqe"><span>Trending</span> <span class="separator svelte-dggjqe">|</span> <span>Emerging</span></div> `;
    if (category === "Marketing") {
      $$payload.out += "<!--[-->";
      const each_array_1 = ensure_array_like([1, 2]);
      $$payload.out += `<div class="tiles-wrapper svelte-dggjqe"><!--[-->`;
      for (let $$index_1 = 0, $$length2 = each_array_1.length; $$index_1 < $$length2; $$index_1++) {
        each_array_1[$$index_1];
        const each_array_2 = ensure_array_like(Array(6));
        $$payload.out += `<div class="tiles-grid svelte-dggjqe"><!--[-->`;
        for (let $$index = 0, $$length3 = each_array_2.length; $$index < $$length3; $$index++) {
          each_array_2[$$index];
          $$payload.out += `<div class="tile svelte-dggjqe"></div>`;
        }
        $$payload.out += `<!--]--></div>`;
      }
      $$payload.out += `<!--]--></div>`;
    } else {
      $$payload.out += "<!--[!-->";
    }
    $$payload.out += `<!--]--></div>`;
  }
  $$payload.out += `<!--]--></div></section> <div class="footer-gradient"></div>`;
}
export {
  _page as default
};

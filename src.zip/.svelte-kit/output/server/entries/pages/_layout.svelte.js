import { p as pop, a as push, c as slot, s as stringify } from "../../chunks/index.js";
import { a as attr } from "../../chunks/attributes.js";
import { p as page } from "../../chunks/index2.js";
import { b as base } from "../../chunks/paths.js";
import { e as escape_html } from "../../chunks/escaping.js";
function Header($$payload, $$props) {
  push();
  $$payload.out += `<header class="svelte-4sdbzw"><nav class="svelte-4sdbzw"><svg viewBox="0 0 2 3" aria-hidden="true" class="svelte-4sdbzw"><path d="M0,0 L1,2 C1.5,3 1.5,3 2,3 L2,0 Z" class="svelte-4sdbzw"></path></svg> <ul class="svelte-4sdbzw"><li${attr("aria-current", page.url.pathname === "/home" ? "page" : void 0)} class="svelte-4sdbzw"><a href="/home" class="svelte-4sdbzw">Home</a></li> <li${attr("aria-current", page.url.pathname === "/about" ? "page" : void 0)} class="svelte-4sdbzw"><a href="/about" class="svelte-4sdbzw">Directory</a></li> <li${attr("aria-current", page.url.pathname.startsWith("/sverdle") ? "page" : void 0)} class="svelte-4sdbzw"><a href="/sverdle" class="svelte-4sdbzw">Get Listed</a></li> <li${attr("aria-current", page.url.pathname.startsWith("/create_an_account") ? "page" : void 0)} class="svelte-4sdbzw"><a href="/create_an_account" class="svelte-4sdbzw">Create an Account</a></li></ul> <svg viewBox="0 0 2 3" aria-hidden="true" class="svelte-4sdbzw"><path d="M0,0 L0,3 C0.5,3 0.5,3 1,2 L2,0 Z" class="svelte-4sdbzw"></path></svg></nav></header>`;
  pop();
}
function _layout($$payload, $$props) {
  push();
  $$payload.out += `<a${attr("href", `${stringify(base)}/home`)}>Home</a> <a${attr("href", `${stringify(base)}/create_an_account`)}>Sign Up</a> <div class="app svelte-15e2x1v">`;
  Header($$payload);
  $$payload.out += `<!----> <main class="svelte-15e2x1v"><!---->`;
  slot($$payload, $$props, "default", {});
  $$payload.out += `<!----></main> <footer class="svelte-15e2x1v"><p>© ${escape_html((/* @__PURE__ */ new Date()).getFullYear())} Snow wolf. All Rights Reserved.</p></footer></div>`;
  pop();
}
export {
  _layout as default
};

import{d as a}from"../chunks/CCQyJXcq.js";export{a as start};

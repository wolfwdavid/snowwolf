import{a0 as a}from"./DtE5aD-g.js";a();
